﻿using System.Linq;
using System.Threading.Channels;

namespace linqTZ_11_09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Forma1> lista = File.ReadAllLines("f1_versenyzok.txt")
                .Skip(1)
                .Select(sor => sor.Split(";"))
                .Select(x => new Forma1(x[0], x[1], x[2], int.Parse(x[3]), int.Parse(x[4]), int.Parse(x[5]))).ToList();

            // 1. feladat
            // Keresd meg a Ferrari csapat 2022-ben legalább 150 pontot szerző versenyzőit!
            // Jelenítsd meg a nevüket és pontszámukat, pontszám szerint csökkenő sorrendben!
            Console.WriteLine("1. feladat.");

            lista.Where(x => x.Csapat.Contains("Ferrari") && x.Szezon == 2022 && x.Pontszam >= 150)
                .OrderByDescending(x => x.Pontszam)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.Versenyzo}, {x.Pontszam}"));

            // 2. feladat
            // Keresd meg a brit nemzetiségű versenyzők 2023-as eredményeit, amelyekben legalább 100 pontot szereztek!
            // Jelenítsd meg a nevüket és pontszámukat, név szerint növekvő sorrendben!

            Console.WriteLine();
            Console.WriteLine("2. felcsi");
            lista.Where(x => x.Nemzetiseg == "Brit" && x.Szezon == 2023 && x.Pontszam >= 100)
                .OrderBy(x => x.Versenyzo)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.Versenyzo}, {x.Pontszam}"));

            // 3. feladat
            // Keresd meg azokat a 2024-es szezoneredményeket, amelyeknél a versenyző vezetékneve "S" betűvel kezdődik ÉS legalább 50 pontot szerzett!
            // Jelenítsd meg a versenyző nevét és pontszámát, pontszám szerint csökkenő sorrendben!
            Console.WriteLine();
            Console.WriteLine("3. felcsi");
            lista.Where(x => x.Szezon == 2024 && x.Versenyzo.StartsWith("S") && x.Pontszam >= 50)
                .OrderByDescending(x => x.Pontszam).ToList()
                .ForEach(x => Console.WriteLine($"{x.Versenyzo}, {x.Pontszam}"));

            // 4. feladat
            // Keresd meg a McLaren csapat azon szezoneredményeit, amelyekben legalább 1 futamgyőzelem született!
            // Jelenítsd meg a versenyző nevét, a szezont és a futamgyőzelmek számát, szezon szerint növekvő sorrendben!
            Console.WriteLine();
            Console.WriteLine("4. felcsi");

            lista.Where(x => x.Csapat.Contains("McLaren") && x.Futamgyozelem >= 1)
                .OrderBy(x => x.Szezon).ToList()
                .ForEach(x => Console.WriteLine($"{x.Versenyzo},{x.Szezon}, {x.Futamgyozelem}"));

            // 5. feladat
            // Keresd meg azokat a szezoneredményeket, amelyekben a csapat neve "A" betűvel kezdődik ÉS a pontszám legalább 100!
            // Jelenítsd meg a versenyző nevét, csapatát és pontszámát, pontszám szerint csökkenő sorrendben!

            Console.WriteLine();
            Console.WriteLine("5. felcsi");

            lista.Where(x => x.Csapat.StartsWith("A") && x.Pontszam >= 100)
                .OrderByDescending(x => x.Pontszam).ToList()
                .ForEach(x => Console.WriteLine($"{x.Versenyzo},{x.Csapat}, {x.Pontszam}"));

            // 6. feladat
            // Keresd meg a 2021-es szezon eredményei közül a legtöbb pontot szerző versenyzőt!
            // Jelenítsd meg a nevét és pontszámát!

            Console.WriteLine();
            Console.WriteLine("6.felcsi");
            Forma1 legtobbpont2021 = lista.Where(x => x.Szezon == 2021)
                .OrderByDescending(x => x.Pontszam).First();
            Console.WriteLine($"{legtobbpont2021.Versenyzo}, {legtobbpont2021.Pontszam}");

            // 7. feladat
            // Keresd meg a Mercedes csapat szezoneredményei közül a legtöbb futamgyőzelmet tartalmazót!
            // Jelenítsd meg a versenyző nevét, a szezont és a futamgyőzelmek számát!

            Console.WriteLine();
            Console.WriteLine("7.felcsi");
            Forma1 feladat7 = lista.Where(x => x.Csapat == "Mercedes")
                .OrderByDescending(x => x.Futamgyozelem).First();
            Console.WriteLine($"{feladat7.Versenyzo}, {feladat7.Szezon}, {feladat7.Futamgyozelem}");

            // 8. feladat
            // Keresd meg a spanyol versenyzők szezoneredményei közül a legkevesebb pontot tartalmazót!
            // Jelenítsd meg a versenyző nevét, a szezont és a pontszámát!


            Console.WriteLine();
            Console.WriteLine("8.felcsi");
            Forma1 feladat8 = lista.Where(x => x.Nemzetiseg == "Spanyol")
                .OrderBy(x => x.Pontszam).First();
            Console.WriteLine($"{feladat8.Versenyzo}, {feladat8.Szezon}, {feladat8.Pontszam}");

            // 9. feladat
            // Keresd meg a 2024-es szezon eredményei közül a 3 legtöbb pontot tartalmazót!
            // Jelenítsd meg a versenyző nevét és pontszámát!

            Console.WriteLine();
            Console.WriteLine("9.felcsi");
            lista.Where(x => x.Szezon == 2024)
                .OrderByDescending(x => x.Pontszam)
                .Take(3)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.Versenyzo},{x.Pontszam}"));
           


            // 10. feladat
            // Keresd meg a legalább 1 futamgyőzelmet tartalmazó szezoneredmények közül az 5 legkevesebb pontot tartalmazót!
            // Jelenítsd meg a versenyző nevét, a szezont és pontszámát!

            Console.WriteLine();
            Console.WriteLine("10. felcsi");

            lista.Where(x => x.Futamgyozelem >= 1)
                .OrderBy(x => x.Pontszam)
                .Take(5)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.Versenyzo}, {x.Szezon}, {x.Pontszam}"));

            // 11. feladat
            // Csoportosítsd a 2022-es szezon legalább 100 pontos eredményeit csapatonként!
            // Jelenítsd meg csapatonként az ilyen eredmények darabszámát!

            //ToDictionary(x => x.Key, x=>x.Count())
            Console.WriteLine();
            Console.WriteLine("11. felcsi");

            lista.Where(x => x.Szezon == 2022 && x.Pontszam >= 100)
                .GroupBy(x => x.Csapat).ToList()
                .ForEach(x => Console.WriteLine($"{x.Key} - {x.Count()}"));

            // 12. feladat
            // Csoportosítsd a 2023-as szezon legalább 1 futamgyőzelmet tartalmazó eredményeit nemzetiségenként!
            // Jelenítsd meg nemzetiségenként az összes futamgyőzelem számát!
            Console.WriteLine();
            Console.WriteLine("12. felcsi");
            lista.Where(x => x.Szezon == 2023 && x.Futamgyozelem >= 1)
                .GroupBy(x => x.Nemzetiseg).ToList()
                .ForEach(x => Console.WriteLine($"{x.Key} - {x.Count()}"));

            // 13. feladat
            // Csoportosítsd a legalább 150 pontos szezoneredményeket szezononként!
            // Jelenítsd meg szezononként az ilyen eredmények átlagos pontszámát!

            Console.WriteLine();
            Console.WriteLine("13. felcsi");

            lista.Where(y => y.Pontszam >= 150)
                .GroupBy(y => y.Szezon).ToList()
                .ForEach(x => Console.WriteLine($"{x.Key}, {x.Average(y => y.Pontszam)}"));

            // 14. feladat
            // Csoportosítsd a 2024-es szezon eredményeit csapatonként!
            // Jelenítsd meg a csapatokat és az összesített pontszámukat, összpontszám szerint csökkenő sorrendben!

            Console.WriteLine();
            Console.WriteLine("14. felcsi");

            lista.Where(x => x.Szezon == 2024)
                .GroupBy(x => x.Csapat)
                .OrderByDescending(z => z.Sum(x => x.Pontszam))
                .ToList()
                .ForEach(y => Console.WriteLine($"{y.Key}, {y.Sum(z => z.Pontszam)}"));

            // 15. feladat
            // Csoportosítsd az összes szezoneredményt nemzetiségenként!
            // Jelenítsd meg a nemzetiségeket és a szezoneredmények átlagos pontszámát, átlag szerint csökkenő sorrendben!

            Console.WriteLine();
            Console.WriteLine("15. felcsi");
            lista.GroupBy(x => x.Nemzetiseg)
                .OrderByDescending(y => y.Average(x => x.Pontszam))
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.Key}, {x.Average(y => y.Pontszam)}"));

            // 16. feladat
            // Csoportosítsd a szezoneredményeket csapatonként!
            // Csak azokat a csapatokat jelenítsd meg, amelyekhez legalább 10 szezoneredmény tartozik!
            // Jelenítsd meg a csapat nevét és az eredmények darabszámát!

            Console.WriteLine();
            Console.WriteLine("16. felcsi");
            lista.GroupBy(x => x.Csapat)
                .Where(y => y.Count() >= 10)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.Key}, {x.Count()}"));


            // 17. feladat
            // Csoportosítsd a szezoneredményeket versenyzőnként!
            // Csak azokat a versenyzőket jelenítsd meg, akiknek az összesített pontszáma meghaladja a 700 pontot!
            // Jelenítsd meg a versenyző nevét és összesített pontszámát!

            Console.WriteLine();
            Console.WriteLine("17. felcsi");

            lista.GroupBy(x => x.Versenyzo)
                .Select(y => new { Nev = y.Key, Total = y.Sum(x => x.Pontszam) })
                .Where(x => x.Total > 700)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.Nev},{x.Total}"));

            // 18. feladat
            // Csoportosítsd a szezoneredményeket szezononként!
            // Csak azokat a szezonokat jelenítsd meg, amelyekben legalább 5 versenyző szerzett 150 vagy több pontot!
            // Jelenítsd meg a szezont és az ilyen versenyzők darabszámát!

            Console.WriteLine();
            Console.WriteLine("18. felcsi");

            lista.GroupBy(x => x.Szezon)
                .Select(y => new { szezon = y.Key, count = y.Count(z => z.Pontszam >= 150) })
                .Where(x => x.count >= 5)
                .OrderBy(x => x.szezon)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.szezon}, {x.count}"));

            // 19. feladat
            // Csoportosítsd a szezoneredményeket nemzetiségenként!
            // Csak azokat a nemzetiségeket jelenítsd meg, amelyekhez tartozó szezoneredmények átlagos pontszáma meghaladja a 150 pontot!
            // Jelenítsd meg a nemzetiséget és az átlagos pontszámot!

            Console.WriteLine();
            Console.WriteLine("19. felcsi");


            lista.GroupBy(x => x.Nemzetiseg)
                .Select(y => new {nemzetiseg = y.Key, pontszam = y.Average(x => x.Pontszam)})
                .Where(x => x.pontszam >= 150)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.nemzetiseg}, {x.pontszam}"));




            // 20. feladat
            // Csoportosítsd a szezoneredményeket csapatonként!
            // Csak azokat a csapatokat jelenítsd meg, amelyek összesített futamgyőzelmeinek száma meghaladja a 10-et!
            // Jelenítsd meg a csapat nevét és az összes futamgyőzelem számát!
            Console.WriteLine();
            Console.WriteLine("20. felcsi");

            lista.GroupBy(x => x.Csapat)
                .Select(y => new { csapat = y.Key, futamGy = y.Sum(x => x.Futamgyozelem) })
                .Where(y => y.futamGy >= 10)
                .ToList()
                .ForEach(x => Console.WriteLine($"{x.csapat}, {x.futamGy}"));

        }
    }
}
