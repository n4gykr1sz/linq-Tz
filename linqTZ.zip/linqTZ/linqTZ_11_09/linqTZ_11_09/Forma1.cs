﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linqTZ_11_09
{
    public class Forma1
    {
        private string _versenyzo;
        private string _csapat;
        private string _nemzetiseg;
        private int _szezon;
        private int _pontszam;
        private int _futamgyozelem;

        public string Versenyzo { get { return _versenyzo; } set { _versenyzo = value; } }
        public string Csapat { get { return _csapat; } set { _csapat = value; } }
        public string Nemzetiseg { get { return _nemzetiseg; } set { _nemzetiseg = value; } }
        public int Szezon { get { return _szezon; } set { _szezon = value; } }
        public int Pontszam { get { return _pontszam; } set { _pontszam = value; } }
        public int Futamgyozelem { get { return _futamgyozelem; } set { _futamgyozelem = value; } }

        public Forma1(string versenyzo, string csapat, string nemzetiseg, int szezon, int pontszam, int futamgyozelem)
        {
            Versenyzo = versenyzo;
            Csapat = csapat;
            Nemzetiseg = nemzetiseg;
            Szezon = szezon;
            Pontszam = pontszam;
            Futamgyozelem = futamgyozelem;
        }

        public override string ToString()
        {
            return $"{Versenyzo}, {Csapat}, {Nemzetiseg}, {Szezon}, {Pontszam}, {Futamgyozelem}";
        }
    }
}
